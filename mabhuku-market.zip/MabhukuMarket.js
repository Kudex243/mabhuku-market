import React from "react";
export default function MabhukuMarket() {
  return (
    <main style={{ fontFamily: "sans-serif", padding: "2rem", textAlign: "center" }}>
      <h1 style={{ fontSize: "2.5rem" }}>Mabhuku Market</h1>
      <p>Publish, sell, and discover Zimbabwean stories.</p>
    </main>
  );
}
