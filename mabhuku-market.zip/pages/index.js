import MabhukuMarket from '../MabhukuMarket';
export default function Home() {
  return <MabhukuMarket />;
}
